package it.alten.webapp.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name="lettore")
public class Lettore {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	@Column(nullable = false)
	private String nomeLettore;
	@Column(nullable = false)
	private String cognomeLettore;
	@Column(nullable = false)
	@OneToMany(mappedBy="lettore", fetch = FetchType.EAGER)
	private List<Libro> libri;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getNomeLettore() {
		return nomeLettore;
	}
	public void setNomeLettore(String nomeLettore) {
		this.nomeLettore = nomeLettore;
	}
	public String getCognomeLettore() {
		return cognomeLettore;
	}
	public void setCognomeLettore(String cognomeLettore) {
		this.cognomeLettore = cognomeLettore;
	}
	public List<Libro> getLibri() {
		return libri;
	}
	public void setLibri(List<Libro> libri) {
		this.libri = libri;
	}
	
}
