package it.alten.webapp.services;

import it.alten.webapp.dao.LettoreDAO;
import it.alten.webapp.rest.dto.LettoreDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("LettoreService")
@Transactional

public class LettoreServiceImpl implements LettoreService {
	 
	 @Autowired
	 private LettoreDAO lettoreDAO;
	 
	 public LettoreDTO getLettore(LettoreDTO lettore) throws Exception {
		 try{
			 lettore=lettoreDAO.getLettore(lettore);
	    }catch(Exception e){
	    	System.out.println("Si è verificato un errore nella get del lettore");
	    	throw new Exception();
	    }
	    return lettore;
	 }

	 

	}


