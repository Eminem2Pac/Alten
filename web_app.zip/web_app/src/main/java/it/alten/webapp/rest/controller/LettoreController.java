package it.alten.webapp.rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import it.alten.webapp.rest.dto.LettoreDTO;
import it.alten.webapp.services.LettoreService;

@RestController
@RequestMapping("/lettore")
public class LettoreController {
	@Autowired
	private LettoreService lettoreService;

	@RequestMapping(value = "/getLettore/{nomeLettore}/{cognomeLettore}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE })

	public LettoreDTO getLettore(@PathVariable("nomeLettore") String nomeLettore,
			@PathVariable("cognomeLettore") String cognomeLettore) throws Exception {
		System.out.println("richiamo getLettore costruendo l'oggetto Lettore");
		LettoreDTO lettoreDTO = new LettoreDTO();
		lettoreDTO.setNomeLettore(nomeLettore);
		lettoreDTO.setCognomeLettore(cognomeLettore);
		return lettoreService.getLettore(lettoreDTO);
	}
}
