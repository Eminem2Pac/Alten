package it.alten.webapp.dao;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import it.alten.webapp.entity.Lettore;
import it.alten.webapp.repository.LettoreRepository;
import it.alten.webapp.rest.dto.LettoreDTO;

@Component("LettoreDAO")
public class LettoreDAOImpl implements LettoreDAO {
	@Autowired
	private LettoreRepository lettoreRepository;
    @Autowired
    private EntityManager entityManager;
	@Transactional
	public LettoreDTO getLettore(LettoreDTO lettore) throws Exception {
		Lettore l = new Lettore();
		l = lettoreRepository.findByNomeLettoreAndCognomeLettore(lettore.getNomeLettore(), lettore.getCognomeLettore())
				.get(0);
		if (l == null) {
			throw new Exception();
		} else {
			lettore.setLettoreId(l.getId());
			return lettore;
		}
	}	
}
