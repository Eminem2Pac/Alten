package it.alten.webapp.services;

import it.alten.webapp.rest.dto.LettoreDTO;

	public interface LettoreService {
	 public LettoreDTO getLettore(LettoreDTO lettore) throws Exception;
	}
