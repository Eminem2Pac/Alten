package it.alten.webapp.dao;

import it.alten.webapp.rest.dto.LettoreDTO;


public interface LettoreDAO {
	 public LettoreDTO getLettore(LettoreDTO lettore) throws Exception ;
	}