package it.alten.webapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import it.alten.webapp.entity.Lettore;

@Repository("LettoreRepository")
public interface LettoreRepository extends JpaRepository<Lettore,Long>{
	List<Lettore> findByNomeLettoreAndCognomeLettore(String nomeLettore, String cognomeLettore);
}
