package it.alten.webapp.services;

import java.util.LinkedList;
import java.util.List;

import it.alten.webapp.dao.LettoreDAO;
import it.alten.webapp.rest.dto.LettoreDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("lettoreService")
@Transactional

public class LettoreServiceImpl implements LettoreService {
	 
	 @Autowired
	 private LettoreDAO lettoreDAO;
	 
	 public LettoreDTO addLettore(LettoreDTO lettore) {
		 try{
	    System.out.println("Richiamo il LettoreDAO per aggiungere l'utente alla base di dati");
	    lettore = lettoreDAO.addLettore(lettore);
		return lettore;
		 }catch(Exception e){
			 System.out.println("Lettore gia' presente nel DB, lettore non inserito");
			 return null;
		 }
	 }

	 public LettoreDTO updateLettore(LettoreDTO lettore) {
		 System.out.println("Richiamo il LettoreDAO per aggiornare l'utente della base di dati");
		 try {
			lettore = lettoreDAO.updateLettore(lettore);
		} catch (Exception e) {
			System.out.println("Si è verificato un errore nell'update del lettore");
			return null;
		}
		 return lettore;
	 }

	 public LettoreDTO deleteLettore(LettoreDTO lettore) {
		 try {
			lettore=lettoreDAO.deleteLettore(lettore);
		} catch (Exception e) {
			System.out.println("Si è verificato un errore nella delete del lettore");
			return null;
		}
		 return lettore;
	 }

	 public LettoreDTO getLettore(LettoreDTO lettore) throws Exception {
		 try{
			 lettore=lettoreDAO.getLettore(lettore);
	    }catch(Exception e){
	    	System.out.println("Si è verificato un errore nella get del lettore");
	    	throw new Exception();
	    }
	    return lettore;
	 }

	 public List<LettoreDTO> getAllLettori() throws Exception{
		 List<LettoreDTO> lettoriDTO = new LinkedList<LettoreDTO>();
		 try{
		   lettoreDAO.getAllLettori();
		   return lettoriDTO;
		   }catch(Exception e){
			   System.out.println("Si è verificato un errore nella getAll dei lettori");
			 return null;  
		   }
	 
	 }

	}


