package it.alten.webapp.dao;

public interface LibroDAO {

}
