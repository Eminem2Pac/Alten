package it.alten.webapp.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import it.alten.webapp.rest.dto.LettoreDTO;
import it.alten.webapp.rest.dto.StatusDTO;
import it.alten.webapp.services.LettoreService;

@RestController
@RequestMapping("/lettore")

public class LettoreController {

	@Autowired(required = true)
	private LettoreService lettoreService;

	@RequestMapping(value = "/{nomeLettore}/{cognomeLettore}", method = RequestMethod.GET, produces = {
			MediaType.APPLICATION_JSON_VALUE })

	public LettoreDTO getLettore(@PathVariable("nomeLettore") String nomeLettore,
			@PathVariable("cognomeLettore") String cognomeLettore) throws Exception {
		System.out.println("richiamo getLettore costruendo l'oggetto Lettore");
		LettoreDTO lettoreDTO = new LettoreDTO();
		lettoreDTO.setNomeLettore(nomeLettore);
		lettoreDTO.setCognomeLettore(cognomeLettore);
		return lettoreService.getLettore(lettoreDTO);
	}

	@RequestMapping(value = "/", method = RequestMethod.POST, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public LettoreDTO addLettore(@RequestBody LettoreDTO lettore) {
		System.out.println("richiamo addLettore" + lettore.getNomeLettore());
		lettore = lettoreService.addLettore(lettore);
		return lettore;
	}

	@RequestMapping(value = "/{nomeLettore}/{cognomeLettore}", method = RequestMethod.PUT, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public LettoreDTO updateLettore(@RequestBody LettoreDTO lettore) {

		lettore = lettoreService.addLettore(lettore);
		return lettore;
	}

	@RequestMapping(value = "/", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<LettoreDTO> getAll() throws Exception {
		return lettoreService.getAllLettori();
	}

	@RequestMapping(value = "/{nomeLettore}/{cognomeLettore}", produces = { MediaType.APPLICATION_JSON_VALUE })
	public StatusDTO deleteLettore(@PathVariable("nomeLettore") String nomeLettore,
			@PathVariable("cognomeLettore") String cognomeLettore) {

		LettoreDTO lettoreDTO = new LettoreDTO();
		lettoreDTO.setNomeLettore(nomeLettore);
		lettoreService.deleteLettore(lettoreDTO);
		StatusDTO status = new StatusDTO();
		status.setMessage("Lettore Cancellato con successo");
		status.setStatus(200);
		return status;
	}

}
