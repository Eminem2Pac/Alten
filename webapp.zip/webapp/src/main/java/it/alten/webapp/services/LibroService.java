package it.alten.webapp.services;

public interface LibroService {

}
