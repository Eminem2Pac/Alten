package it.alten.webapp.dao;

public class LibroDAOImpl implements LibroDAO{

}
