package it.alten.webapp.dao;

public interface BibliotecaDAO {
	
	
	
}
