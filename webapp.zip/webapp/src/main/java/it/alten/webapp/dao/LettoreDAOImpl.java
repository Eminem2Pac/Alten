package it.alten.webapp.dao;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import it.alten.webapp.entity.Lettore;
import it.alten.webapp.repository.LettoreRepository;
import it.alten.webapp.rest.dto.LettoreDTO;

//@Component("lettoreDAO")
public class LettoreDAOImpl implements LettoreDAO {

	@Autowired
	private LettoreRepository lettoreRepository;

	/*
	 * @Autowired(required=true) private EntityManager entityManager;
	 */

	@Transactional
	public LettoreDTO addLettore(LettoreDTO lettore) throws Exception {
		Lettore l = new Lettore();
		l = lettoreRepository.findByNomeLettoreAndCognomeLettore(lettore.getNomeLettore(), lettore.getCognomeLettore())
				.get(0);
		if (l == null) {
			l = lettoreRepository.save(l);//in questo modo se un oggetto nuovo con stessi nome e cognome di uno gia' esistente viene attached all'entity manager e facciamo il save, lui lo considera una tupla nuova e gli assegna un nuovo id(chiave) e lo troviamo duplicato, con la eccezione rimuovo questo problema
			lettore.setLettoreId(l.getId());
			return lettore;
		} else {
			throw new Exception();
		}
	}
	@Transactional
	public LettoreDTO updateLettore(LettoreDTO lettore) throws Exception {
		Lettore l = new Lettore();
		l = lettoreRepository.findByNomeLettoreAndCognomeLettore(lettore.getNomeLettore(), lettore.getCognomeLettore())
				.get(0);
		if (l == null) {
			try {
				return this.addLettore(lettore);
			} catch (Exception e) {
				throw new Exception();
			}
		} else {
			l = lettoreRepository.save(l);
		}
		return lettore;
	}
	
	@Transactional
	public LettoreDTO deleteLettore(LettoreDTO lettore) throws Exception {
		Lettore l = new Lettore();
		l = lettoreRepository.findByNomeLettoreAndCognomeLettore(lettore.getNomeLettore(), lettore.getCognomeLettore())
				.get(0);
		if (l == null) {
			throw new Exception();
		} else {
			l = lettoreRepository.deleteByNomeLettoreAndCognomeLettore(lettore.getNomeLettore(),lettore.getCognomeLettore()).get(0);
			lettore.setLettoreId(l.getId());
			return lettore;
		}
	}
	
	@Transactional
	public LettoreDTO getLettore(LettoreDTO lettore) throws Exception {
		Lettore l = new Lettore();
		l = lettoreRepository.findByNomeLettoreAndCognomeLettore(lettore.getNomeLettore(), lettore.getCognomeLettore())
				.get(0);
		if (l == null) {
			throw new Exception();
		} else {
			lettore.setLettoreId(l.getId());
			return lettore;
		}
	}

	@Transactional
	public List<LettoreDTO> getAllLettori() throws Exception {
		List<Lettore> lettori = new LinkedList<Lettore>();
		lettori = lettoreRepository.findAll();
		if (lettori == null) {
			throw new Exception();
		} else {
			List<LettoreDTO> lettoriDTO = new LinkedList<LettoreDTO>();
			for(Lettore l:lettori){
				LettoreDTO lettoreDTO = new LettoreDTO();
				lettoreDTO.setLettoreId(l.getId());
				lettoreDTO.setNomeLettore(l.getNomeLettore());
				lettoreDTO.setCognomeLettore(l.getCognomeLettore());
				lettoriDTO.add(lettoreDTO);
			}
			return lettoriDTO;
		}
	}
}
