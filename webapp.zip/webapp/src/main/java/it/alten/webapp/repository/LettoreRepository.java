package it.alten.webapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import it.alten.webapp.entity.Lettore;

//@Repository
public interface LettoreRepository extends JpaRepository<Lettore,Long>{
	
	List<Lettore> findByNomeLettoreAndCognomeLettore(String nomeLettore, String cognomeLettore);
	/*@Query("update Lettore l set l.nomeLettore = ?1, l.cognomeLettore = ?2 where l.id = ?3")
	public Lettore updateLettore(String nomeLettore, String cognomeLettore, long id);
	@Query("delete from Lettore l where l.id = ?1")
	public Lettore deleteLettore(long id);*/
	public List<Lettore> deleteByNomeLettoreAndCognomeLettore(String nomeLettore, String cognomeLettore);
	public List<Lettore> findAll();
	
}
