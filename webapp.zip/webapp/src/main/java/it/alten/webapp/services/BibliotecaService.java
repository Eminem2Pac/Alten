package it.alten.webapp.services;

public interface BibliotecaService {

}
