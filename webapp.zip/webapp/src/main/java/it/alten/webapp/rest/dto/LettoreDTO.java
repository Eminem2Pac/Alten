package it.alten.webapp.rest.dto;

import java.io.Serializable;

public class LettoreDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private long lettoreId;
	private String nomeLettore;
	private String cognomeLettore;

	public long getLettoreId() {
		return lettoreId;
	}

	public void setLettoreId(long lettoreId) {
		this.lettoreId = lettoreId;
	}

	public String getNomeLettore() {
		return nomeLettore;
	}

	public void setNomeLettore(String nomeLettore) {
		this.nomeLettore = nomeLettore;
	}

	public String getCognomeLettore() {
		return cognomeLettore;
	}

	public void setCognomeLettore(String cognomeLettore) {
		this.cognomeLettore = cognomeLettore;
	}
}
