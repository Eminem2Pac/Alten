package it.alten.webapp.rest.controller;

public class BibliotecaController {

}
