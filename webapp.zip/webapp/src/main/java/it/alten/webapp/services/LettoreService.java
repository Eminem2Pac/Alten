package it.alten.webapp.services;


	import java.util.List;

import it.alten.webapp.rest.dto.LettoreDTO;

	public interface LettoreService {
	 public LettoreDTO addLettore(LettoreDTO lettore);
	 public LettoreDTO updateLettore(LettoreDTO lettore);
	 public LettoreDTO deleteLettore(LettoreDTO lettore);
	 public LettoreDTO getLettore(LettoreDTO lettore) throws Exception;
	 public List<LettoreDTO> getAllLettori() throws Exception;
	}
