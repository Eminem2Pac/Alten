package it.alten.webapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import it.alten.webapp.entity.Biblioteca;

public interface BibliotecaRepository extends JpaRepository<Biblioteca,Long>{
	
	List<Biblioteca> findByNomeBiblioteca(String nomeBiblioteca);
	
}