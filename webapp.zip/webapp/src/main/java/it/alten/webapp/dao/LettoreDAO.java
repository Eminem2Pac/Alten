package it.alten.webapp.dao;

import java.util.List;

import it.alten.webapp.rest.dto.LettoreDTO;


public interface LettoreDAO {
	 public LettoreDTO addLettore(LettoreDTO lettore) throws Exception;
	 public LettoreDTO updateLettore(LettoreDTO lettore) throws Exception;
	 public LettoreDTO deleteLettore(LettoreDTO lettore) throws Exception;
	 public LettoreDTO getLettore(LettoreDTO lettore) throws Exception ;
	 public List<LettoreDTO> getAllLettori() throws Exception;
	}