package it.alten.webapp.dao;

public class BibliotecaDAOImpl implements BibliotecaDAO {

}
