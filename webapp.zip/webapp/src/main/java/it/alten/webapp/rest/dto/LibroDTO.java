package it.alten.webapp.rest.dto;

public class LibroDTO {

}
